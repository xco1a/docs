#define 喵喵喵 main

#define 喵喵 int

#define 喵 (

#define 喵喵呜 )

#define 喵喵喵喵 {

#define 喵呜喵 }

#define 喵呜喵呜喵 printf

#define 呜 "\n"

#define 喵呜喵呜 return

#define 呜喵 0

#define 喵呜 ;

#include <stdio.h>

喵喵 喵喵喵 喵 喵喵呜

喵喵喵喵 

喵呜喵呜喵 喵 "喵喵喵! " 呜 喵喵呜 喵呜

喵呜喵呜 呜喵 喵呜

喵呜喵 